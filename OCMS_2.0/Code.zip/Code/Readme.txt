Directory Structure of the code:

1. The zip file OCMS_2.0 has all the php and other files.
2. After downloading the xampp server and creating a database on Phpmyadmin as mentioned in "Installation guide".
   The file is ready to work on localhost. So on local host we will type:http://localhost/OCMS_2.0/login.php.
3. This will open the first login page and then other pages can be open and according to the functionality.
   The OCMS_2.0 zip file has several php files and sql files. All sql files are implemented in phpmyadmin.
   Now following is the list of all the php files with their functions:
   
   Login.php--First page of the system.
   welcome.php--for registration in the system
   home.php -- home page for student
   home1.php -- home page for supervisor
   Attendance.php--attendance sheet for student to mark their presence.
   profileme.php�profile page for supervisor and student.
   viewattendance.php-- to view the attendance for supervisor.
   supervisorlogin.php-- for supervisor login with username and password.
   Studentlogin.php-- for student login with username and password.
   logout.php -- to logout from home page and to go back to the login page.
   Events.php -- to create events by supervisor for students
   register.php -- to register for the application
   viewevents1.php -- to view all the students who have registered for the events.
   viewevents.php -- to view all the events given by the supervisor.