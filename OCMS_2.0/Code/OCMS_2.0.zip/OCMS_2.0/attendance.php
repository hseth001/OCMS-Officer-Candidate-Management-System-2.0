<?php
session_start();
if ($_SERVER['REMOTE_ADDR']=='::1') {
    $ip = '127.0.0.1';
}else{
    $ip = $_SERVER['REMOTE_ADDR'];
}
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
if (isset($_POST['Mark_Attendance_btn'])){

	$username = mysql_real_escape_string($_POST['username']);

		$sql = "INSERT INTO attendance(sign, datetime, ip) VALUES ('$username', now(), '$ip')";
		mysqli_query($db,$sql);

		$_SESSION['sign']= $username;
		// header("location:home.php"); 
	}







?>

<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/css/bootstrap-combined.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" media="screen"
     href="http://tarruda.github.com/bootstrap-datetimepicker/assets/css/bootstrap-datetimepicker.min.css">
<body>
<div class ="header">
<h1><em><i>Attendance Sheet</em> <i> </h1>
</div>

<div class="container" style="height:0px; ">
<div class="container">
<div class="row">
<br>
<br>
<form method ="post" action ="attendance.php"> 

Dear <?=$_SESSION['username'];?>, 
Please sign below to mark your attendance.
<table width="900px" border=0> 

<tr> 
<td>Signature</td>
<td><input type="text" name= "username" class= "textInput" required></td>
</tr>
</table>

<div style="text-align:center;">
<tr>
<td> <input type="submit" class="button1" name="Mark_Attendance_btn" value="Mark Attendance" > </td>
<td> <a href="home.php"><input type="submit" class="button1" name="Back_btn" value="Back"></a> </td>
</tr>
<tr>
<div  style="text-align:center">
<script type="text/javascript"
     src="http://cdnjs.cloudflare.com/ajax/libs/jquery/1.8.3/jquery.min.js">
    </script> 
    <script type="text/javascript"
     src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.2.2/js/bootstrap.min.js">
    </script>
    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.min.js">
    </script>
    <script type="text/javascript"
     src="http://tarruda.github.com/bootstrap-datetimepicker/assets/js/bootstrap-datetimepicker.pt-BR.js">
    </script>
    <script type="text/javascript">
      $('#datetimepicker').datetimepicker({
        'dateFormat': "YYYY-MM-DD",
  'timeFormat': "HH:mm:ss"
      });
    </script>
</tr>
</div>
</div>
</div>
</div>
</div>
</form>
 
    
</body>
</html>
