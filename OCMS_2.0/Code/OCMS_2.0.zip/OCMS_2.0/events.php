<?php

session_start();
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
if (isset($_POST['CreateEvent'])){
	$description = mysql_real_escape_string($_POST['description']);
	$title = mysql_real_escape_string($_POST['title']);
	$location = mysql_real_escape_string($_POST['location']);
	$time = mysql_real_escape_string($_POST['time']);
	$sql= "INSERT INTO events(description,title,location,time) VALUES ('$description','$title', '$location','$time')";
	mysqli_query($db,$sql);
	// $result= mysqli_query ($db,$sql);
	// if($result){
		// echo"";
	// }
	header("location:home1.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>OFFICER CANDIDATE MANAGEMENT SYSTEM</center></em></i>
<br>
</div>

<div class="container">
<div class="container" style="height:0px;">
<form action="events.php" method ="POST">
  <fieldset>
    <legend>CREATE NEW EVENT:</legend>
    Description:<br>
	<input type="text" name="description"  class= "textInput" required>
    <br>
    Title:<br>
    <input type="text" name="title" class= "textInput" required>
    <br>
	Location:<br>
    <input type="text" name="location" class= "textInput" required>
    <br>
	Time:<br>
    <input type="text" name="time" class= "textInput" required>
    <br><br>
	<tr>
<td> <input type="submit" class="button1" name="CreateEvent" value="Submit" > </td>
<td> <a href="home1.php"><input type="submit" class="button1" name="Back_btn" value="Back"></a> </td>
</tr>
    
  </fieldset>
</form>

</div>
</div>
</body>
</html>