<?php
session_start();

?>



<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	
</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>!Welcome Home!<br> <?=$_SESSION['username'];?></br></center></em></i>
</div>
<div class="container" style="height:0px;">
<br>
<br>
<div class="container">
 
  <ul class="nav nav-pills nav-stacked">
    
    <li class="active"><a href="profileme.php">Profile</a></li>
    <li ><a href="viewattendance.php">ViewAttendance</a></li>
    <li ><a href="events.php">Create Events</a></li>
    <li ><a href="viewevents1.php">Students Enrolled</a></li>
	<li ><a href="logout.php">Logout</a></li>
  </ul>
</div>
</div>
<div style="text-align:left;"> </div>
</div>
</div>


</body>


</html>
