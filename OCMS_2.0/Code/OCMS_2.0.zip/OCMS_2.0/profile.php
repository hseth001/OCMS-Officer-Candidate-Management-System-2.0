<?php
require ("home.php");
function getUsersData($id)
{
	$array = array();
	$q = mysql_query("SELECT * FROM 'studentlogin' WHERE 'id'=".$id);
	while($r= mysql_fetch_assoc($q))
	{
		$array ['id'] = $row ['id'];
		$array ['username'] = $row ['username'];
		$array ['email'] = $row ['email'];
		$array ['phonenumber'] = $row ['phonenumber'];
		$array ['school'] = $row ['school'];
		$array ['rank'] = $row ['rank'];
		$array ['academicyear'] = $row ['academicyear'];
		$array ['Role'] = $row ['Role'];
		
		
	}
	return $array;
}



?>