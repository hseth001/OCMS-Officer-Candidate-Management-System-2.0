<?php

session_start();

 $error = '';
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

//if (isset($_POST['login_btn'])){
	if (isset($_POST['username'])){
			$username = stripslashes($_REQUEST['username']);
        //escapes special characters in a string
	$username = mysqli_real_escape_string($db,$username);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($db,$password);
	 $query = "SELECT * FROM `studentlogin` WHERE username='$username' and password='".md5($password)."'";
	 $result = mysqli_query($db,$query) or die(mysql_error());
	 
	 $rows = mysqli_num_rows($result);
	  if($rows==1){
		  $_SESSION['username'] = $username;
		     header("Location: home1.php");
         }else{
			$error = 'Wrong username or password';
			 	
	
		 }}
	
	
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title> OFFICER CANDIDATE MANAGEMENT SYSTEM </title>

<link rel="stylesheet" href="css/style.css" />
</head>
<link rel="stylesheet" type="text/css" href="style2.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
	</head>
	<div class ="header">
<h1> <em> <i>SUPERVISOR LOGIN</em></i></h1>
</div>
 
	<body>
	<div class="container" style="height:0px;">
<div class="form">
<form method ="post" action ="" name="login">

<table border=0>
<tr>
<td>Username: </td>
<td><input type="text" name= "username" class= "form-control" required></td>
</tr>

<tr> 
<td>Password: </td>
<td><input type="password" name= "password" class= "form-control" required></td>
</tr>
<tr>
<td colspan=2>
<div style = "font-size:12px; color:#cc0000; padding:10px;"><?php echo $error; ?></div>
</td></tr>
<tr>
<td colspan=2> 
<div class="text-center">
<input type="submit" class="button1" name="Login_btn" value="LOGIN" >
<br>
<a href="login.php"><input type="submit" class="button" name="Back_btn" value="BACK"></a>

</div>
</div>
</div>
</tr>

</table>

</form>

</div>
</body>
</html>