<?php
session_start();


?>
<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style4.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
</head>
<body>
<div class ="header">
<h1><em><i>VIEW ATTENDANCE</em> <i> </h1>
<br>
</div>
<div class="container" style="height:0px;">
</div>
</body>
</html>

<?php
   // connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
    // Check connection
	$user_ip=getenv('REMOTE_ADDR');
	$geo=unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
	$region=$geo["geoplugin_regionName"];
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
     
    $query = "SELECT sign, datetime,ip FROM attendance order by sign" ;
	
      if($result = $db->query($query))
{
    while($row = $result->fetch_assoc())
    { echo "</br>";
echo '<div class="container">';
        
        echo '<div class="col-md-8" style="border: 1px solid black;">';
		  echo '<div class="row" style="border: 0px solid black; margin-left:50px;">';
		  echo "<b>Sign:</b> ". $row['sign'];
		  echo '</div>';
		 
        echo '<div class="row" style="border: 0px solid black; margin-left:50px;">';
		  echo "<b>Date/Time:</b> ". $row['datetime'];
		  echo '</div>';
        echo '<div class="row" style="border: 0px solid black; margin-left:50px;">';
			echo "<b>IP:</b> ". $row['ip'];
		  echo '</div>';
        echo "</br>";
	
        

echo '</div>';
		echo '</div>';
        
    }
}
   

    
    ?>
	
	