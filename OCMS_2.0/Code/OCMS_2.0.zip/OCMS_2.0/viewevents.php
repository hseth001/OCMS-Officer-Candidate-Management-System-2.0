<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "user_login_system");
$username = $_SESSION["username"];
// Join Event code 
if(isset($_POST["event"])) {
    $event = mysql_real_escape_string($_POST['event']);
    $sql = "INSERT INTO student_event(student, event) VALUES ('$username', '$event')";
    mysqli_query($db,$sql);

}


?>
<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style1.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>JOIN ANY LISTED EVENTS</center></em></i>
<br>
</div>

<div class="container">
<div class="container" style="height:0px;">
<?php
   // connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $query = "SELECT description,title,location,time FROM events";
	
	
      if($result = $db->query($query))
{
    while($row = $result->fetch_assoc())
    { 
echo '<div class="container">';
  echo '<div class="row" style="width:100%;border:1px solid black;">';
    echo '<div class="col-sm-5">';
      echo "<b>Title:</b> ". $row['title'];
      echo "<br/><b>Description:</b> ".$row['description'];
      echo "<br/><b>Location:</b> ".$row['location'];
      echo "<br/><b>Time:</b> ".$row['time'];
?>
<form action="" method="POST" class="form-inline" role="form" style="width:100%;margin:0;">
  <input type="hidden" class="form-control" name="event" value="<?php echo $row['title'] ?>">
  <button type="submit" class="btn btn-primary">Join - <?php echo $row['title'] ?></button>
   <button Type="button" class="btn btn-primary" onClick="history.go(-1);return true;">BACK</button>	
</form>
<?php
    echo '</div>';
  echo '</div>';
echo "</div>";
    }
}
?>

</div>

</div>
</body>
</html>

