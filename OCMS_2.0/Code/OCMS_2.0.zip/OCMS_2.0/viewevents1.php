<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "user_login_system");
$username = $_SESSION["username"];
// Join Event code 
if(isset($_POST["event"])) {
    $event = mysql_real_escape_string($_POST['event']);
    $sql = "INSERT INTO student_event(student, event) VALUES ('$username', '$event')";
    mysqli_query($db,$sql);

}


?>
<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style1.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
<body>
<div class ="header">
<em><i style="font-family: 'Algerian'; font-size:25px;"><center>STUDENTS ENROLLED</center></em></i>
<br>
</div>
<br>
<div class="container">
<div class="container" style="height:0px;">
<?php
   // connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $query = "SELECT description,title,location,time FROM events";
	
	
      if($result = $db->query($query))
{
    while($row = $result->fetch_assoc())
    {
      echo '<div class="container">';
        echo '<div class="row" style="width:100%;border:1px solid black;">';
          echo '<div class="col-sm-5">';
            echo "<b>Title:</b> ". $row['title'];
            echo "<br/><b>Description:</b> ".$row['description'];
            echo "<br/><b>Location:</b> ".$row['location'];
            echo "<br/><b>Time:</b> ".$row['time'];

            $student_event_query = "SELECT * FROM student_event WHERE event='".$row['title']."'";
            if($student_event_result = $db->query($student_event_query)){
              echo '<br/><b>Joined Students:</b>';
              $a=0;
              while($student_event_row = $student_event_result->fetch_assoc())
              {
                if ($a >0) {
                  echo ',';
                }
                echo $student_event_row['student'];
                $a++;
              }
            }

          echo '</div>';
        echo '</div>';
      echo "</div>";
    }
}
?>

</div>

</div>
</body>
</html>
