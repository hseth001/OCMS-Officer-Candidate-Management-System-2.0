<?php
session_start();
// connect to database
$db = mysqli_connect("localhost", "root", "", "user_login_system");
if (isset($_POST['Register_btn'])){
	
	$username = mysql_real_escape_string($_POST['username']);
	$email = mysql_real_escape_string($_POST['email']);
	$phonenumber = mysql_real_escape_string($_POST['phonenumber']);
	$school = mysql_real_escape_string($_POST['school']);
	$rank = mysql_real_escape_string($_POST['rank']);
	$academicyear = mysql_real_escape_string($_POST['academicyear']);
	$Role = mysql_real_escape_string($_POST['Role']);
	$password = mysql_real_escape_string($_POST['password']);
	$confirmpassword = mysql_real_escape_string($_POST['confirmpassword']);
	if ($password == $confirmpassword)
	{
		//create user
		$password = md5($password);// hash password
		$confirmpassword = md5($confirmpassword);
		$sql = "INSERT INTO studentlogin(username, email, phonenumber, school, rank, academicyear,Role, password, confirmpassword) VALUES ('$username','$email', '$phonenumber','$school','$rank','$academicyear','$Role','$password', '$confirmpassword')";
		mysqli_query($db,$sql);
		$_SESSION['message']= "You are now logged in";
		$_SESSION['username']= $username;
        if ($role=='Student') {
            header("location:home.php"); // redirect to home page
        }else{
            header("location:home1.php"); // redirect to home page
        }
		

		}else{
			$_SESSION['message']= "The two passwords do not match";
			
	
			
		} 
		
		
		
	}

?>
<!DOCTYPE html>
<html>
<head>
<title>OFFICER CANDIDATE MANAGEMENT SYSTEM</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<body>
<div class ="header">
<h1><em><i>OFFICER CANDIDATE MANAGEMENT SYSTEM</em> <i> </h1>
</div>
<div class ="container">
<form method ="post" action ="register.php"> 
<form class="form-horizontal" role="form">
                
				
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">username:</label>
                    <div class="col-sm-6">
                        <input type="text" "id="firstName" size="50" placeholder="Username" name="username" class="form-control" required >
                    </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">email:</label>
                    <div class="col-sm-9">
                        <input type="email" id="email" size="50" placeholder="Email" name= "email" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="phonenumber" class="col-sm-3 control-label">phonenumber:</label>
                    <div class="col-sm-9">
                        <input type="number_format" id="number" size="50" placeholder="Phonenumber" name= "phonenumber" class="form-control" required>
                    </div>
                </div>
				<div class="form-group">
                    <label for="school" class="col-sm-3 control-label">school:</label>
                    <div class="col-sm-9">
                        <select id="school"  placeholder="school" name= "school" class="form-control" required>
                            <option>---</option>
							<option>Florida International University</option>
                            <option>Broward College</option>
                            <option>Florida Atlantic University</option>
                            <option>Miami Dade College</option>
                            <option>Florida Memorial University</option>
                            <option>Florida State University</option>
                            <option>University of Miami</option>
                            <option>Barry University</option>
                        </select>
                    </div>
                </div> <!-- /.form-group -->
				
				                <div class="form-group">
                    <label for="rank" class="col-sm-3 control-label">rank:</label>
                    <div class="col-sm-9">
                        <select id="rank"  placeholder="rank" name= "rank" class="form-control" required>
                            <option>---</option>
							<option>Cadet</option>
                            <option>Cadre</option>
                        </select>
                    </div>
                </div> <!-- /.form-group -->
				
                <div class="form-group">
                    <label for="academicyear" class="col-sm-3 control-label">academicyear:</label>
                    <div class="col-sm-9">
                        <input type="date" id="academicyear" size="50" name= "academicyear" class="form-control" required>
                    </div>
                </div>
				
								 <div class="form-group">
                    <label for="Role" class="col-sm-3 control-label">Role:</label>
                    <div class="col-sm-9">
                        <select id="Role"  placeholder="Role" name= "Role" class="form-control" required>
                            <option>---</option>
							<option>Student</option>
                            <option>Supervisor</option>
                        </select>
                    </div>
                </div>
				
				 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">password:</label>
                    <div class="col-sm-9">
                        <input type="password" id="password" size="50" placeholder="Password" name= "password" class="form-control" required>
                    </div>
                </div>
				
				 <div class="form-group">
                    <label for="confirmpassword" class="col-sm-3 control-label">confirmpassword:</label>
                    <div class="col-sm-9">
                        <input type="password" id="confirmpassword" size="50" placeholder="Confirmpassword" name= "confirmpassword" class="form-control" required>
                    </div>
                </div>
<br>
<div style="text-align:left;">
<tr>
<input type="submit" class="button1" name="Register_btn" value="REGISTER" >
<a href="login.php"><input type="submit" class="button1" name="Login_btn" value="LOGIN"></a>



</tr>
</div>
</div>
</form>
 
</form>
</body>
</html>
