--
-- Database: `user_login_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `sign` varchar(100) NOT NULL,
  `datetime` datetime NOT NULL,
  `ip` text NOT NULL,
  `ID` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`sign`, `datetime`, `ip`, `ID`) VALUES
('hans', '2016-11-20 17:13:44', '0', 13),
('hansini seth', '2016-11-20 19:32:48', '0', 14),
('hansini', '2016-11-20 23:05:20', '0', 15),
('ishan shrivastava', '2016-11-20 23:30:33', '0', 16),
('John', '2016-12-02 19:20:49', '0', 19),
('123456789765467', '2016-12-02 20:01:50', '0', 23),
('John1', '2016-12-02 20:12:19', '0', 24),
('hansinni265448573', '2017-01-25 21:11:12', '0', 25),
('ishan00000', '2017-02-13 20:18:04', '0', 26),
('hansini9999999', '2017-02-13 21:07:07', '0', 27),
('hooooooooooooooo', '2017-02-13 21:27:10', '0', 28),
('rrggtt', '2017-02-19 18:40:03', '0', 29),
('a1a1a1', '2017-03-08 14:57:21', '0', 30),
('vikrant', '2017-03-09 06:40:19', '127.0.0.1', 32),
('hahahahahah', '2017-03-08 20:37:06', '127.0.0.1', 33),
('pooooooooooooooo', '2017-03-08 20:48:15', '127.0.0.1', 34),
('ffffffffffffffffffff', '2017-03-08 21:20:08', '', 35),
('hansini 1234', '2017-03-09 19:43:52', '127.0.0.1', 36),
('hansini 1234', '2017-03-09 19:44:50', '127.0.0.1', 37),
('hansini 1234', '2017-03-09 19:46:43', '127.0.0.1', 38),
('hansini 1234', '2017-03-09 19:47:09', '127.0.0.1', 39),
('hansini 1234', '2017-03-09 19:47:37', '127.0.0.1', 40),
('hansini 1234', '2017-03-09 19:48:04', '127.0.0.1', 41),
('hansini 1234', '2017-03-09 19:48:29', '127.0.0.1', 42),
('Ajay', '2017-03-13 16:38:04', '127.0.0.1', 43),
('usha12345', '2017-03-29 14:22:34', '127.0.0.1', 44),
('Mickey', '2017-04-07 22:54:52', '127.0.0.1', 45),
('rekha jain', '2017-04-12 16:26:43', '127.0.0.1', 46);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `description` varchar(10000) NOT NULL,
  `title` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `time` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`description`, `title`, `location`, `time`) VALUES
('miami fun festival', 'festival', 'south beach', '09:00:00.000000'),
('fit n fun', 'fitness', 'south beach', '10:00:00.000000'),
('holi', 'holi indian event', 'miami', '08:00:00.000000'),
('GTV', 'Photo Gallery Grid', 'miami', '10:00:00.000000'),
('running event', 'run', 'miami', '07:00:00.000000'),
('marathon', 'running event', 'florida', '06:00:00.000000'),
('100 km ', 'running marathon', 'miami', '05:00:00.000000'),
('logistics lead', 'sajkdkas', 'bdscbsb', '09:00:00.000000'),
('hjhgjg', 'sobe', 'asdasdas', '10:00:00.000000'),
('miami beach', 'waterfloat', 'south beach', '09:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE `studentlogin` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phonenumber` int(100) NOT NULL,
  `school` enum('Florida International University','Barry University','Broward College','Miami Dade College','University of Miami','Florida Memorial University','FLorida Atlantic University') NOT NULL,
  `rank` enum('CADRE','CADET') NOT NULL,
  `academicyear` int(100) NOT NULL,
  `Role` enum('Student','Supervisor') NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirmpassword` varchar(100) NOT NULL,
  `profileimage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentlogin`
--

INSERT INTO `studentlogin` (`username`, `email`, `phonenumber`, `school`, `rank`, `academicyear`, `Role`, `password`, `confirmpassword`, `profileimage`) VALUES
('aish', 'aish@gmail.com', 2147483647, 'FLorida Atlantic University', 'CADRE', 2017, 'Student', '9e3895cedfa93fc7d6f63cb00ad91d1b', 'zaq', ''),
('aish', 'aish@njbsdjbas', 2147483647, '', 'CADRE', 1, '', '62f2596b743b732c244ca5451a334b4f', 'zaq1', ''),
('ajay', 'aj@gmail.com', 2147483647, 'Broward College', 'CADET', 2, 'Student', '3bad6af0fa4b8b330d162e19938ee981', 'qqqq', ''),
('akshay', 'akshay@gmail.com', 2147483647, 'Broward College', 'CADET', 3, 'Supervisor', 'c769d3c6031b7943b46bf198a29057d2', 'akki', ''),
('nancy', 'av@gmail.com', 2147483647, 'Broward College', 'CADRE', 2, 'Supervisor', '8ace72535e8ea08b22681721a437a6f5', 'poiuyt', ''),
('david', 'david@jhsd', 2147483647, '', '', 4, 'Supervisor', '2c216b1ba5e33a27eb6d3df7de7f8c36', '1qaz', ''),
('hansini', 'hansini.sims@gmail.com', 2147483647, 'Broward College', 'CADET', 1, 'Student', '827ccb0eea8a706c4c34a16891f84e7b', '12345', 'uploads/hansini/bea2d.jpg'),
('vikrant2', 'hbjbj@dnxm.com', 2147483647, 'Florida International University', 'CADET', 2017, 'Supervisor', 'e10adc3949ba59abbe56e057f20f883e', '123456', ''),
('hseth', 'hseth001@fiu.edu', 2147483647, 'Florida Memorial University', 'CADRE', 23, 'Supervisor', 'ce827a5f1df5b82656d6ecebf1cd20ab', 'qwas', ''),
('ishan', 'ishan2266@gmail.com', 2147483647, 'University of Miami', 'CADET', 2, 'Supervisor', '962012d09b8170d912f0669f6d7d9d07', 'qwer', 'uploads/ishan/bea3h.jpg'),
('John', 'jh@gmail.com', 2147483647, 'Florida International University', 'CADRE', 2017, 'Supervisor', 'a384b6463fc216a5f8ecb6670f86456a', 'qwert', ''),
('john', 'john@gmail.com', 2147483647, 'FLorida Atlantic University', 'CADET', 2017, 'Student', '7085ed00bd92dc3160e1c1e9841a0f35', 'qwerr', ''),
('kailash', 'kailash@gmail.com', 2147483647, 'Miami Dade College', 'CADET', 2, 'Supervisor', '77bffc9ce3544fe5177da67c29a2efde', '1234r', ''),
('megha', 'megha@gmail.com', 2147483647, '', 'CADRE', 3, 'Student', '69830ca86240b626dd9943f6fe4d54c2', 'lkjh', ''),
('mohan', 'mohan@gmail.com', 2147483647, 'FLorida Atlantic University', 'CADET', 1, 'Supervisor', '2c216b1ba5e33a27eb6d3df7de7f8c36', '1qaz', ''),
('hjdshfkshdfh', 'n@basmdbs', 98731273, 'Florida International University', 'CADET', 2, '', '962012d09b8170d912f0669f6d7d9d07', 'qwer', ''),
('neeraj', 'n@gmail.com', 2147483647, 'Miami Dade College', 'CADET', 2, 'Supervisor', '6ca29d9bb530402bd09fe026ee838148', 'poiu', ''),
('nancy', 'nancy@hotmail.com', 987654321, 'Broward College', 'CADET', 1, '', '6ca29d9bb530402bd09fe026ee838148', 'poiu', ''),
('neetu', 'neetu@gmail.com', 2147483647, 'Miami Dade College', 'CADET', 1, 'Student', '53c1df01e11ec01bcf9ced4ccae8c667', 'qwsa', ''),
('rekha', 'rekha@gmail.com', 2147483647, 'FLorida Atlantic University', 'CADET', 1, 'Student', 'cf9c29e1a7a83717d82fa8407771820d', 'rekha@123', 'uploads/rekha/bea4e.jpg'),
('sirisha', 'siri@gmail.com', 2147483647, '', '', 1, 'Supervisor', 'a5a7158118e59ee590424b55bb9aed17', '0909', ''),
('summit', 'summit@jkhdsjhas', 2147483647, 'Miami Dade College', 'CADET', 5, 'Supervisor', '912ec803b2ce49e4a541068d495ab570', 'asdf', ''),
('usha', 'usha@gmail.com', 2147483647, 'Florida Memorial University', 'CADRE', 1, 'Student', '460e926a82572ff6a6c29523b814c9ca', '2wsx', ''),
('vikrant', 'vikrant.rise@gmail.com', 2147483647, 'Florida International University', 'CADRE', 2017, 'Student', 'e10adc3949ba59abbe56e057f20f883e', '123456', 'uploads/vikrant/profile.jpg'),
('yashi', 'yashi@gmail.com', 2147483647, 'Miami Dade College', 'CADRE', 3, 'Student', '2d7acadf10224ffdabeab505970a8934', 'pppp', ''),
('yashi', 'yashi@hotmail.com', 2147483647, 'Florida Memorial University', '', 3, 'Student', '62cadae65f54888f214aa0673003ab59', 'mnbvc', '');

-- --------------------------------------------------------

--
-- Table structure for table `table_image`
--

CREATE TABLE `table_image` (
  `id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `image` blob NOT NULL,
  `type` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_image`
--

INSERT INTO `table_image` (`id`, `name`, `image`, `type`) VALUES
(1, '', '', ''),
(2, '', '', ''),
(3, '', '', ''),
(4, '', '', ''),
(5, '', '', ''),
(6, '', '', ''),
(7, '', '', ''),
(8, '', '', ''),
(9, '', '', ''),
(10, '', '', ''),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, '', '', ''),
(15, '', '', ''),
(16, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`title`);

--
-- Indexes for table `studentlogin`
--
ALTER TABLE `studentlogin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `table_image`
--
ALTER TABLE `table_image`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `table_image`
--
ALTER TABLE `table_image`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
